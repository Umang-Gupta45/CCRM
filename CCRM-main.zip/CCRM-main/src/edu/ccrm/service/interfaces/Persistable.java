package edu.ccrm.service.interfaces;

public interface Persistable {
    void save();
    void load();
}
